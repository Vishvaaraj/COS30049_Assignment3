---
title: COS30049 GP14 Assign3
emoji: 🔥
colorFrom: red
colorTo: red
sdk: docker
pinned: false
short_description: For random_forest, xgboost, and kmeans
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
