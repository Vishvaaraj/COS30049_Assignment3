import joblib
import pandas as pd
import numpy as np
from scipy.stats import mode as scipy_mode

# --- 1. Load all artifacts at startup ---
# This is efficient as it's done only once.
try:
    scaler = joblib.load('ml_artifacts/scaler.pkl')
    label_encoders = joblib.load('ml_artifacts/label_encoders.pkl')
    target_encoder = joblib.load('ml_artifacts/label_encoder_target.pkl')
    model_rf = joblib.load('ml_artifacts/model_random_forest.pkl')
    model_xgb = joblib.load('ml_artifacts/model_xgboost.pkl')
    model_kmeans = joblib.load('ml_artifacts/model_kmeans.pkl')
    
    # Load the dataset to compute medians, modes, and centroids for preprocessing.
    df = pd.read_csv('ml_artifacts/processed_network_data.csv')

except FileNotFoundError as e:
    raise RuntimeError(f"A required ML artifact was not found: {e}. Ensure the `ml_artifacts` directory is present.")


# --- 2. Pre-compute values for preprocessing ---
# These are cached in memory for the lifetime of the app.
NUMERIC_FEATURES = ['duration', 'src_bytes', 'dst_bytes', 'count', 'srv_count', 'serror_rate']
CATEGORICAL_FEATURES = ['protocol_type', 'service', 'flag']
ALL_FEATURES_ORDERED = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'count', 'srv_count', 'serror_rate']

# Medians for numeric imputation
numeric_medians = df[NUMERIC_FEATURES].median().to_dict()

# Modes for categorical imputation
# NOTE: scipy.stats.mode() no longer accepts non-numeric (string) input as of
# SciPy 1.11 — it raises TypeError. pandas' own .mode() works on any dtype and
# is the correct tool here.
categorical_modes = {col: df[col].mode()[0] for col in CATEGORICAL_FEATURES}

# --- 3. Core preprocessing pipeline ---
# NOTE: this must be defined BEFORE get_kmeans_labels() below, because
# get_kmeans_labels() calls it immediately at module load time (not lazily) —
# Python only resolves function bodies when they're called, so the original
# ordering (preprocess_data defined after its first caller) compiled fine but
# crashed at runtime with NameError: name 'preprocess_data' is not defined.
def preprocess_data(data: pd.DataFrame):
    """
    Takes a DataFrame of raw features and applies the full preprocessing pipeline.
    Returns the scaled data ready for model inference and a list of warnings.
    """
    warnings = []
    df_processed = data.copy()

    # Impute missing values
    for col in NUMERIC_FEATURES:
        df_processed[col] = df_processed[col].fillna(numeric_medians[col])
    for col in CATEGORICAL_FEATURES:
        df_processed[col] = df_processed[col].fillna(categorical_modes[col])

    # Label encode categorical features, handling unseen values
    for col in CATEGORICAL_FEATURES:
        le = label_encoders[col]
        # Most frequent class in the encoder's own training vocabulary, used as
        # a safe fallback when inference-time data contains a category the
        # LabelEncoder never saw (le.transform() would otherwise raise).
        fallback_class = categorical_modes[col] if categorical_modes[col] in le.classes_ else le.classes_[0]

        def replace_unseen(value):
            if value not in le.classes_:
                warnings.append(f"Unseen value '{value}' in column '{col}' was replaced with fallback '{fallback_class}'.")
                return fallback_class
            return value

        # Step 1: swap out any unseen values for the fallback (still strings).
        # Step 2: now that every value is guaranteed to be in le.classes_,
        # le.transform() is safe to call on the whole column at once.
        cleaned_col = df_processed[col].apply(replace_unseen)
        df_processed[col] = le.transform(cleaned_col)

    # Ensure feature order is correct before scaling
    df_processed = df_processed[ALL_FEATURES_ORDERED]

    # Scale the data
    scaled_data = scaler.transform(df_processed)

    return scaled_data, warnings


# --- 4. K-Means specific preprocessing: Determine cluster labels ---
def get_kmeans_labels():
    """
    Determines which KMeans cluster ID corresponds to "Normal" vs "Anomaly".
    This is a one-time operation at startup.
    """
    # Take a sample of known "Normal" traffic from the training data
    normal_df = df[df['category'] == 'Normal'].sample(n=100, random_state=42)
    
    # Preprocess this sample exactly like any other inference data
    processed_normal, _ = preprocess_data(normal_df.drop('category', axis=1))
    
    # Predict the cluster for these known-normal samples
    normal_clusters = model_kmeans.predict(processed_normal)

    # The most common cluster for normal data is our "Normal" cluster.
    # normal_clusters is a numeric numpy array (cluster ids), so scipy's mode
    # works fine here — the earlier bug was only about mode() on STRING columns.
    normal_cluster_id = int(scipy_mode(normal_clusters, keepdims=True).mode[0])
    
    # The other cluster is "Anomaly"
    anomaly_cluster_id = 1 - normal_cluster_id
    
    return {normal_cluster_id: "Normal", anomaly_cluster_id: "Anomaly"}

kmeans_cluster_labels = get_kmeans_labels()


# --- 5. Per-model inference logic ---
SEVERITY_MAPPING_MULTICLASS = {
    "Normal": "Low", "Probe": "Medium", "R2L": "High", "DoS": "Critical", "U2R": "Critical"
}
SEVERITY_MAPPING_KMEANS = {"Normal": "Low", "Anomaly": "Critical"}

def predict_multiclass(model, X_scaled):
    """Inference for RandomForest or XGBoost."""
    probabilities = model.predict_proba(X_scaled)[0]
    predicted_class_idx = np.argmax(probabilities)
    confidence = float(probabilities[predicted_class_idx])
    
    predicted_class = target_encoder.inverse_transform([predicted_class_idx])[0]
    
    # Create the full probabilities dictionary
    probs_dict = {cls: float(prob) for cls, prob in zip(target_encoder.classes_, probabilities)}
    
    return {
        "predicted_class": predicted_class,
        "confidence": confidence,
        "probabilities": probs_dict,
        "severity": SEVERITY_MAPPING_MULTICLASS.get(predicted_class, "High")
    }

def predict_kmeans(X_scaled):
    """Inference for KMeans."""
    cluster_id = model_kmeans.predict(X_scaled)[0]
    predicted_class = kmeans_cluster_labels[cluster_id]
    
    # Calculate pseudo-confidence based on distance to centroid
    distance = np.linalg.norm(X_scaled[0] - model_kmeans.cluster_centers_[cluster_id])
    confidence = 1 / (1 + distance) # Normalize distance to a 0-1 score
    
    # For KMeans, probabilities are simplified. Cast to plain Python float
    # (not np.float64) so the values serialize cleanly and consistently with
    # predict_multiclass's output, regardless of which JSON encoder is used
    # downstream.
    probs_dict = {"Normal": 0.0, "Anomaly": 0.0}
    if predicted_class == "Normal":
        probs_dict["Normal"] = float(confidence)
        probs_dict["Anomaly"] = float(1 - confidence)
    else:
        probs_dict["Anomaly"] = float(confidence)
        probs_dict["Normal"] = float(1 - confidence)

    return {
        "predicted_class": predicted_class,
        "confidence": float(confidence),
        "probabilities": probs_dict,
        "severity": SEVERITY_MAPPING_KMEANS.get(predicted_class, "Critical")
    }

# A single dispatch function to handle all models
MODEL_DISPATCH = {
    "random_forest": (model_rf, predict_multiclass),
    "xgboost": (model_xgb, predict_multiclass),
    "kmeans": (model_kmeans, predict_kmeans)
}
