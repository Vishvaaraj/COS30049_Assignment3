import os
from supabase import create_client, Client

SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY")

# Hugging Face Spaces can fail if the secret is missing.
# We ensure the service crashes early so it's obvious to the user.
if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError("Missing SUPABASE_URL or SUPABASE_SERVICE_KEY environment variables.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def insert_alert(alert_data: dict):
    """
    Inserts a single alert into the `alerts` table.
    """
    try:
        response = supabase.table("alerts").insert(alert_data).execute()
        return response.data
    except Exception as e:
        print(f"Failed to insert alert: {e}")
        raise e

def get_recent_alerts(limit: int = 10):
    """
    Fetches the most recent `limit` alerts from the `alerts` table.
    """
    try:
        response = supabase.table("alerts").select("*").order("timestamp", desc=True).limit(limit).execute()
        return response.data
    except Exception as e:
        print(f"Failed to fetch alerts: {e}")
        raise e
