import time
import json
import pandas as pd
from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import io
import random

from app.ml import (
    preprocess_data, MODEL_DISPATCH, ALL_FEATURES_ORDERED,
    df as dataset_df # Import the loaded dataset dataframe
)
from app.supabase_client import insert_alert, get_recent_alerts

app = FastAPI(
    title="AI4Cyber Anomaly Detection API",
    description="Serves ML models for network intrusion detection.",
    version="1.0.0"
)

# --- CORS Middleware ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Caching data computed at startup ---
DATASET_STATS = {
    "total_records": len(dataset_df),
    "class_distribution": dataset_df['category'].value_counts().to_dict()
}

MODEL_STATS = {
  "random_forest": {
    "accuracy": 0.9974,
    "macro_precision": 0.93,
    "macro_recall": 0.97,
    "macro_f1": 0.95,
    "per_class": {
      "DoS": { "precision": 1.0, "recall": 1.0, "f1": 1.0, "support": 9186 },
      "Normal": { "precision": 1.0, "recall": 1.0, "f1": 1.0, "support": 13469 },
      "Probe": { "precision": 0.99, "recall": 0.99, "f1": 0.99, "support": 2331 },
      "R2L": { "precision": 0.96, "recall": 0.97, "f1": 0.97, "support": 199 },
      "U2R": { "precision": 0.69, "recall": 0.9, "f1": 0.78, "support": 10 },
    },
    "feature_importance": {
      "src_bytes": 0.22, "service": 0.185, "dst_bytes": 0.133, "srv_count": 0.101,
      "count": 0.088, "serror_rate": 0.087, "duration": 0.07, "flag": 0.068, "protocol_type": 0.042,
    },
  },
  "xgboost": {
    "accuracy": 0.9973,
    "macro_precision": 0.91,
    "macro_recall": 0.98,
    "macro_f1": 0.94,
    "per_class": {
      "DoS": { "precision": 1.0, "recall": 1.0, "f1": 1.0, "support": 9186 },
      "Normal": { "precision": 1.0, "recall": 1.0, "f1": 1.0, "support": 13469 },
      "Probe": { "precision": 0.99, "recall": 0.99, "f1": 0.99, "support": 2331 },
      "R2L": { "precision": 0.94, "recall": 0.99, "f1": 0.96, "support": 199 },
      "U2R": { "precision": 0.64, "recall": 0.9, "f1": 0.75, "support": 10 },
    },
    "feature_importance": {
      "src_bytes": 0.21, "service": 0.178, "dst_bytes": 0.141, "srv_count": 0.098,
      "count": 0.09, "serror_rate": 0.085, "duration": 0.073, "flag": 0.071, "protocol_type": 0.053,
    },
  },
  "kmeans": {
    "accuracy": 0.8739,
    "per_class": {
      "Normal": { "precision": 0.9, "recall": 0.9, "f1": 0.9 },
      "Anomaly": { "precision": 0.85, "recall": 0.85, "f1": 0.85 },
    },
    "feature_importance": [
        { "feature": "src_bytes", "importance": 0.18 }, { "feature": "dst_bytes", "importance": 0.15 },
        { "feature": "logged_in", "importance": 0.12 }, { "feature": "count", "importance": 0.1 },
        { "feature": "srv_serror_rate", "importance": 0.08 }, { "feature": "dst_host_srv_count", "importance": 0.07 },
        { "feature": "dst_host_same_srv_rate", "importance": 0.06 }, { "feature": "dst_host_diff_srv_rate", "importance": 0.05 },
        { "feature": "dst_host_serror_rate", "importance": 0.04 }, { "feature": "protocol_type", "importance": 0.03 },
    ],
  },
};

# --- Helper Functions ---
def generate_placeholder_ip():
    return f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"

def process_and_predict(data: pd.DataFrame, model_name: str):
    if model_name not in MODEL_DISPATCH:
        raise HTTPException(status_code=400, detail=f"Invalid model name '{model_name}'.")

    model, predict_fn = MODEL_DISPATCH[model_name]
    
    results = []
    class_counts = {}

    for i, row in data.iterrows():
        start_time = time.time()
        
        row_df = pd.DataFrame([row], columns=data.columns)
        X_scaled, warnings = preprocess_data(row_df)
        
        prediction_result = predict_fn(model, X_scaled)
        
        inference_time_ms = round((time.time() - start_time) * 1000)
        
        pred_class = prediction_result["predicted_class"]
        class_counts[pred_class] = class_counts.get(pred_class, 0) + 1
        
        final_row = {
            "row_id": i,
            "predicted_class": pred_class,
            "confidence": prediction_result["confidence"],
            "probabilities": prediction_result["probabilities"],
            "model_used": model_name,
            "inference_time_ms": inference_time_ms,
            "severity": prediction_result["severity"],
            "features": row.to_dict()
        }
        if warnings:
            final_row["warnings"] = warnings
        results.append(final_row)

        if pred_class != "Normal":
            insert_alert({
                "class": pred_class,
                "severity": prediction_result["severity"],
                "confidence": prediction_result["confidence"],
                "source_ip": generate_placeholder_ip(),
                "model_used": model_name
            })
            
    return results, class_counts

# --- API Endpoints ---
@app.post("/predict")
async def predict(
    model: str = Form(...),
    file: Optional[UploadFile] = File(None),
    record: Optional[str] = Form(None)
):
    if not file and not record:
        raise HTTPException(status_code=422, detail="Either 'file' or 'record' must be provided.")
    if file and record:
        raise HTTPException(status_code=422, detail="Provide either 'file' or 'record', not both.")

    if file:
        try:
            contents = await file.read()
            df = pd.read_csv(io.StringIO(contents.decode('utf-8')))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to read or parse CSV file: {e}")
    else:
        try:
            record_data = json.loads(record)
            df = pd.DataFrame([record_data])
        except (json.JSONDecodeError, TypeError) as e:
            raise HTTPException(status_code=400, detail=f"Failed to parse JSON record: {e}")

    for col in ALL_FEATURES_ORDERED:
        if col not in df.columns:
            df[col] = None

    rows, class_counts = process_and_predict(df, model)
    
    return {
        "rows": rows,
        "summary": {
            "total_rows": len(rows),
            "class_counts": class_counts,
            "model_used": model
        }
    }

@app.get("/model-stats")
def model_stats(model: str = Query(..., description="The model to get stats for.")):
    if model not in MODEL_STATS:
        raise HTTPException(status_code=404, detail=f"Model '{model}' not found.")
    return MODEL_STATS[model]

@app.get("/dataset-stats")
def dataset_stats():
    return DATASET_STATS

@app.get("/alerts")
def alerts(limit: int = Query(10, ge=1, le=100)):
    try:
        return get_recent_alerts(limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch alerts from database: {e}")
